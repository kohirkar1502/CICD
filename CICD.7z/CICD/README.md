# GitLab CI/CD + Terraform Demo

This project demonstrates a basic CI/CD pipeline using GitLab and Terraform to provision an AWS EC2 instance and deploy a Python app.

## Structure

- `.gitlab-ci.yml`: CI/CD pipeline definition
- `terraform/`: Infrastructure code
- `scripts/deploy.sh`: Deployment script
- `app/main.py`: Sample Python application

## Prerequisites

- AWS credentials
- GitLab Runner
- Terraform installed

## Usage

1. Push to GitLab to trigger pipeline
2. Review and manually apply Terraform plan
3. App is deployed via SSH to EC2

## Notes

- Replace `<instance-ip>` in `deploy.sh` with actual IP
- Customize `main.py` as needed
