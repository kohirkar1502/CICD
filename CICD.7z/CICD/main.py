import platform

def main():
    print("Hello from your deployed app!")
    print("System info:", platform.platform())

if __name__ == "__main__":
    main()
