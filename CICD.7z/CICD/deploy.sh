#!/bin/bash
echo "Deploying application..."
scp app/main.py ec2-user@<instance-ip>:/home/ec2-user/
ssh ec2-user@<instance-ip> "python3 /home/ec2-user/main.py"
